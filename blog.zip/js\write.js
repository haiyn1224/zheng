// ==================== 全局变量 ====================
let uploadedImages = [];

// ==================== 密码验证检查 ====================
function checkAuth() {
    if (!Auth.isAuthenticated()) {
        showPasswordModal();
    }
}

// ==================== 显示密码输入框 ====================
function showPasswordModal() {
    const modal = document.createElement('div');
    modal.id = 'passwordModal';
    modal.innerHTML = `
        <div style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            backdrop-filter: blur(5px);
        ">
            <div style="
                background: white;
                padding: 40px;
                border-radius: 20px;
                text-align: center;
                max-width: 400px;
                width: 90%;
                box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            ">
                <div style="font-size: 3em; margin-bottom: 20px;">🔒</div>
                <h2 style="margin-bottom: 10px; color: #333;">需要验证</h2>
                <p style="color: #666; margin-bottom: 20px;">请输入密码以继续写日记</p>
                <input type="password" id="passwordInput" placeholder="请输入密码" style="
                    width: 100%;
                    padding: 12px;
                    border: 2px solid #ddd;
                    border-radius: 10px;
                    font-size: 1em;
                    margin-bottom: 15px;
                    text-align: center;
                    outline: none;
                " onkeypress="if(event.key==='Enter')verifyPassword()">
                <button onclick="verifyPassword()" style="
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    border: none;
                    padding: 12px 30px;
                    border-radius: 25px;
                    cursor: pointer;
                    font-size: 1em;
                    width: 100%;
                ">验证</button>
                <p id="passwordError" style="color: #e74c3c; margin-top: 10px; display: none;">密码错误，请重试</p>
                <a href="index.html" style="
                    display: block;
                    margin-top: 15px;
                    color: #999;
                    text-decoration: none;
                    font-size: 0.9em;
                ">← 返回首页</a>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    document.getElementById('passwordInput').focus();
}

// ==================== 验证密码 ====================
function verifyPassword() {
    const input = document.getElementById('passwordInput');
    const error = document.getElementById('passwordError');
    
    if (Auth.verify(input.value)) {
        const modal = document.getElementById('passwordModal');
        modal.remove();
    } else {
        error.style.display = 'block';
        input.value = '';
        input.focus();
    }
}

// ==================== 初始化 ====================
function init() {
    // 检查密码验证
    checkAuth();
    
    // 设置默认日期为今天
    document.getElementById('entryDate').valueAsDate = new Date();
    
    // 绑定内容输入事件
    document.getElementById('entryText').addEventListener('input', updatePreview);
    document.getElementById('entryTitle').addEventListener('input', updatePreview);
}

// ==================== 更新预览 ====================
function updatePreview() {
    const title = document.getElementById('entryTitle').value;
    const content = document.getElementById('entryText').value;
    const fontFamily = document.getElementById('fontFamily').value;
    const fontSize = document.getElementById('fontSize').value;
    const fontColor = document.getElementById('fontColor').value;
    const bgColor = document.getElementById('bgColor').value;
    
    const previewBox = document.getElementById('previewBox');
    
    if (!title && !content) {
        previewBox.innerHTML = '<div class="preview-placeholder">内容将在这里显示...</div>';
        previewBox.classList.remove('has-content');
        previewBox.style.background = '#fafafa';
        previewBox.style.fontFamily = 'inherit';
        previewBox.style.fontSize = '1em';
        previewBox.style.color = '#444';
        return;
    }
    
    previewBox.classList.add('has-content');
    previewBox.style.background = bgColor;
    previewBox.style.fontFamily = fontFamily;
    previewBox.style.fontSize = fontSize;
    previewBox.style.color = fontColor;
    
    let html = '';
    if (title) {
        html += `<h2 style="margin-bottom: 15px; color: #333; font-size: 1.3em;">${title}</h2>`;
    }
    if (content) {
        html += `<div style="line-height: 1.8;">${content.replace(/\n/g, '<br>')}</div>`;
    }
    
    previewBox.innerHTML = html;
}

// ==================== 表情包 ====================
function toggleEmojiPanel() {
    const panel = document.getElementById('emojiPanel');
    const btn = document.querySelector('.toggle-emoji');
    
    if (panel.classList.contains('active')) {
        panel.classList.remove('active');
        btn.textContent = '展开 ▼';
    } else {
        panel.classList.add('active');
        btn.textContent = '收起 ▲';
    }
}

function insertEmoji(emoji) {
    const textarea = document.getElementById('entryText');
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    
    textarea.value = text.substring(0, start) + emoji + text.substring(end);
    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = start + emoji.length;
    
    updatePreview();
}

// ==================== 图片上传 ====================
function handleImageUpload(event) {
    const files = event.target.files;
    
    Array.from(files).forEach(file => {
        // 检查文件大小（限制 5MB）
        if (file.size > 5 * 1024 * 1024) {
            alert(`图片 ${file.name} 太大，请压缩后上传（限制 5MB）`);
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            uploadedImages.push(e.target.result);
            updateImagePreview();
        };
        reader.readAsDataURL(file);
    });
    
    // 清空 input，允许重复选择相同文件
    event.target.value = '';
}

// ==================== 更新图片预览 ====================
function updateImagePreview() {
    const container = document.getElementById('imagePreviewContainer');
    
    if (uploadedImages.length === 0) {
        container.innerHTML = '';
        return;
    }
    
    container.innerHTML = uploadedImages.map((img, index) => `
        <div class="image-preview-item">
            <img src="${img}" alt="预览">
            <button class="remove-btn" onclick="removeImage(${index})">×</button>
        </div>
    `).join('');
}

// ==================== 移除图片 ====================
function removeImage(index) {
    uploadedImages.splice(index, 1);
    updateImagePreview();
}

// ==================== 添加标签 ====================
function addTag(tag) {
    const input = document.getElementById('entryTags');
    const currentTags = input.value.split(',').map(t => t.trim()).filter(t => t);
    
    if (!currentTags.includes(tag)) {
        if (currentTags.length > 0) {
            input.value = currentTags.join(', ') + ', ' + tag;
        } else {
            input.value = tag;
        }
    }
}

// ==================== 保存日记 ====================
function saveEntry() {
    const date = document.getElementById('entryDate').value;
    const title = document.getElementById('entryTitle').value.trim();
    const content = document.getElementById('entryText').value.trim();
    const tags = document.getElementById('entryTags').value;
    const fontFamily = document.getElementById('fontFamily').value;
    const fontSize = document.getElementById('fontSize').value;
    const fontColor = document.getElementById('fontColor').value;
    const bgColor = document.getElementById('bgColor').value;
    
    // 验证
    if (!title) {
        alert('请填写标题');
        document.getElementById('entryTitle').focus();
        return;
    }
    
    if (!content) {
        alert('请填写内容');
        document.getElementById('entryText').focus();
        return;
    }
    
    // 创建日记对象
    const newEntry = {
        id: Date.now(),
        date: date,
        title: title,
        content: content,
        tags: tags.split(',').map(t => t.trim()).filter(t => t),
        images: [...uploadedImages],
        fontFamily: fontFamily,
        fontSize: fontSize,
        fontColor: fontColor,
        bgColor: bgColor,
        createdAt: new Date().toISOString()
    };
    
    // 保存到本地存储
    if (Storage.add(newEntry)) {
        alert('日记保存成功！');
        // 跳转到首页
        window.location.href = 'index.html';
    }
}

// ==================== 拖拽上传 ====================
document.addEventListener('DOMContentLoaded', function() {
    init();
    
    const uploadArea = document.getElementById('imageUploadArea');
    
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.style.borderColor = '#667eea';
        this.style.background = '#f0f0ff';
    });
    
    uploadArea.addEventListener('dragleave', function(e) {
        e.preventDefault();
        this.style.borderColor = '#ddd';
        this.style.background = '#fafafa';
    });
    
    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        this.style.borderColor = '#ddd';
        this.style.background = '#fafafa';
        
        const files = e.dataTransfer.files;
        handleFiles(files);
    });
});

function handleFiles(files) {
    Array.from(files).forEach(file => {
        if (!file.type.startsWith('image/')) {
            alert(`${file.name} 不是图片文件`);
            return;
        }
        
        if (file.size > 5 * 1024 * 1024) {
            alert(`图片 ${file.name} 太大，请压缩后上传（限制 5MB）`);
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            uploadedImages.push(e.target.result);
            updateImagePreview();
        };
        reader.readAsDataURL(file);
    });
}
