// ==================== 配置区域 ====================
const CONFIG = {
    TARGET_DATE: '2028-06-06T00:00:00',
    START_DATE: '2026-06-06T00:00:00'
};

// ==================== 数据存储 ====================
const Storage = {
    KEY: 'our_promise_diary',
    
    // 获取所有日记
    getAll() {
        try {
            const data = localStorage.getItem(this.KEY);
            return data ? JSON.parse(data) : this.getDefaultData();
        } catch (e) {
            console.error('读取数据失败:', e);
            return this.getDefaultData();
        }
    },
    
    // 保存所有日记
    saveAll(entries) {
        try {
            localStorage.setItem(this.KEY, JSON.stringify(entries));
            return true;
        } catch (e) {
            console.error('保存数据失败:', e);
            alert('保存失败，可能是存储空间不足');
            return false;
        }
    },
    
    // 添加日记
    add(entry) {
        const entries = this.getAll();
        entries.unshift(entry);
        return this.saveAll(entries);
    },
    
    // 根据ID获取日记
    getById(id) {
        const entries = this.getAll();
        return entries.find(e => e.id === id);
    },
    
    // 获取默认数据
    getDefaultData() {
        return [
            {
                id: 1,
                date: '2026-06-06',
                title: '约定开始',
                content: '今天我们许下了两年的约定。这段时间里，我们要各自努力，成为更好的自己。两年后，我们再见。',
                tags: ['开始', '约定'],
                images: [],
                fontFamily: 'inherit',
                fontSize: '1em',
                fontColor: '#444'
            },
            {
                id: 2,
                date: '2026-06-01',
                title: '新的开始',
                content: '今天是六月的第一天，也是新生活的开始。为了两年后的约定，我要更加努力。',
                tags: ['开始', '成长'],
                images: [],
                fontFamily: 'inherit',
                fontSize: '1em',
                fontColor: '#444'
            }
        ];
    }
};
