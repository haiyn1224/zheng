// ==================== 获取 URL 参数 ====================
function getUrlParam(name) {
    const params = new URLSearchParams(window.location.search);
    return params.get(name);
}

// ==================== 显示密码验证框 ====================
function showDeletePasswordModal(onSuccess) {
    const modal = document.createElement('div');
    modal.id = 'deletePasswordModal';
    modal.innerHTML = `
        <div style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            backdrop-filter: blur(5px);
        ">
            <div style="
                background: white;
                padding: 40px;
                border-radius: 20px;
                text-align: center;
                max-width: 400px;
                width: 90%;
                box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            ">
                <div style="font-size: 3em; margin-bottom: 20px;">🔒</div>
                <h2 style="margin-bottom: 10px; color: #333;">需要验证</h2>
                <p style="color: #666; margin-bottom: 20px;">请输入密码以删除日记</p>
                <input type="password" id="deletePasswordInput" placeholder="请输入密码" style="
                    width: 100%;
                    padding: 12px;
                    border: 2px solid #ddd;
                    border-radius: 10px;
                    font-size: 1em;
                    margin-bottom: 15px;
                    text-align: center;
                    outline: none;
                " onkeypress="if(event.key==='Enter')verifyDeletePassword()">
                <button onclick="verifyDeletePassword()" style="
                    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
                    color: white;
                    border: none;
                    padding: 12px 30px;
                    border-radius: 25px;
                    cursor: pointer;
                    font-size: 1em;
                    width: 100%;
                ">验证并删除</button>
                <p id="deletePasswordError" style="color: #e74c3c; margin-top: 10px; display: none;">密码错误，请重试</p>
                <button onclick="closeDeleteModal()" style="
                    background: none;
                    border: none;
                    color: #999;
                    margin-top: 15px;
                    cursor: pointer;
                ">取消</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    window.deleteCallback = onSuccess;
    document.getElementById('deletePasswordInput').focus();
}

function verifyDeletePassword() {
    const input = document.getElementById('deletePasswordInput');
    const error = document.getElementById('deletePasswordError');
    
    if (Auth.verify(input.value)) {
        closeDeleteModal();
        if (window.deleteCallback) window.deleteCallback();
    } else {
        error.style.display = 'block';
        input.value = '';
        input.focus();
    }
}

function closeDeleteModal() {
    const modal = document.getElementById('deletePasswordModal');
    if (modal) modal.remove();
    window.deleteCallback = null;
}

// ==================== 删除日记 ====================
function deleteDiary(id) {
    showDeletePasswordModal(() => {
        if (Storage.deleteEntry(id)) {
            alert('日记已删除');
            window.location.href = 'index.html';
        } else {
            alert('删除失败');
        }
    });
}

// ==================== 评论功能 ====================
function renderComments(diaryId) {
    const comments = Storage.getComments(diaryId);
    const container = document.getElementById('commentsSection');
    
    if (!container) return;
    
    const commentsHtml = comments.length > 0 
        ? comments.map(comment => `
            <div class="comment-item" style="
                background: white;
                padding: 15px;
                border-radius: 10px;
                margin-bottom: 10px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            ">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                    <span style="font-weight: 600; color: #667eea;">${comment.author || '匿名'}</span>
                    <span style="font-size: 0.8em; color: #999;">${new Date(comment.createdAt).toLocaleString()}</span>
                </div>
                <p style="color: #444; line-height: 1.6;">${comment.content}</p>
            </div>
        `).join('')
        : '<p style="text-align: center; color: #999; padding: 20px;">暂无评论，来写第一条吧</p>';
    
    container.innerHTML = `
        <div style="margin-top: 30px;">
            <h3 style="color: rgba(255,255,255,0.95); margin-bottom: 20px; font-size: 1.2em;">💬 评论 (${comments.length})</h3>
            <div class="comments-list" style="margin-bottom: 20px;">
                ${commentsHtml}
            </div>
            <div class="comment-form" style="
                background: white;
                padding: 20px;
                border-radius: 15px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            ">
                <input type="text" id="commentAuthor" placeholder="你的名字（可选）" style="
                    width: 100%;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    background: #fafafa;
                    color: #333;
                    margin-bottom: 10px;
                    outline: none;
                ">
                <textarea id="commentContent" placeholder="写下你的评论..." style="
                    width: 100%;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    background: #fafafa;
                    color: #333;
                    min-height: 80px;
                    resize: vertical;
                    margin-bottom: 10px;
                    outline: none;
                "></textarea>
                <button onclick="submitComment(${diaryId})" style="
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    border: none;
                    padding: 10px 25px;
                    border-radius: 20px;
                    cursor: pointer;
                    font-size: 0.95em;
                ">发表评论</button>
            </div>
        </div>
    `;
}

function submitComment(diaryId) {
    const author = document.getElementById('commentAuthor').value.trim() || '匿名';
    const content = document.getElementById('commentContent').value.trim();
    
    if (!content) {
        alert('请输入评论内容');
        return;
    }
    
    if (Storage.saveComment(diaryId, { author, content })) {
        renderComments(diaryId);
    } else {
        alert('评论发表失败');
    }
}

// ==================== 打开图片模态框 ====================
function openImageModal(src) {
    document.getElementById('modalImage').src = src;
    document.getElementById('imageModal').classList.add('active');
}

// ==================== 关闭图片模态框 ====================
function closeImageModal() {
    document.getElementById('imageModal').classList.remove('active');
}

// ==================== 渲染日记详情 ====================
function renderDiaryDetail() {
    const id = parseInt(getUrlParam('id'));
    const contentContainer = document.getElementById('diaryContent');
    const navContainer = document.getElementById('diaryNav');
    
    if (!id) {
        contentContainer.innerHTML = `
            <div class="not-found">
                <h2>日记不存在</h2>
                <p>请检查链接是否正确</p>
                <a href="index.html" class="nav-btn" style="display: inline-block; margin-top: 20px;">返回首页</a>
            </div>
        `;
        return;
    }

    const entry = Storage.getById(id);
    
    if (!entry) {
        contentContainer.innerHTML = `
            <div class="not-found">
                <h2>日记不存在</h2>
                <p>该日记可能已被删除或链接错误</p>
                <a href="index.html" class="nav-btn" style="display: inline-block; margin-top: 20px;">返回首页</a>
            </div>
        `;
        return;
    }

    const start = new Date(CONFIG.START_DATE);
    const entryDate = new Date(entry.date);
    const dayCount = Math.floor((entryDate - start) / (1000 * 60 * 60 * 24)) + 1;
    const dateStr = `${entryDate.getFullYear()}年${entryDate.getMonth() + 1}月${entryDate.getDate()}日`;

    // 渲染图片
    let imagesHtml = '';
    if (entry.images && entry.images.length > 0) {
        if (entry.images.length === 1) {
            imagesHtml = `
                <div class="diary-image-single">
                    <img src="${entry.images[0]}" alt="日记图片" onclick="openImageModal('${entry.images[0]}')">
                </div>
            `;
        } else {
            imagesHtml = `
                <div class="diary-gallery">
                    <div class="gallery-grid">
                        ${entry.images.map(img => `
                            <div class="gallery-item" onclick="openImageModal('${img}')">
                                <img src="${img}" alt="日记图片">
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
    }

    // 应用自定义样式
    const fontFamily = entry.fontFamily || 'inherit';
    const fontSize = entry.fontSize || '1em';
    const fontColor = entry.fontColor || '#444';
    const bgColor = entry.bgColor || 'transparent';

    contentContainer.innerHTML = `
        <article class="diary-detail">
            <header class="diary-header">
                <div class="diary-meta">
                    <span class="diary-date">📅 ${dateStr}</span>
                    <span class="diary-day-count">第 ${dayCount} 天</span>
                </div>
                <h1 class="diary-title">${entry.title}</h1>
            </header>
            <div class="diary-content" style="
                font-family: ${fontFamily};
                font-size: ${fontSize};
                color: ${fontColor};
                background: ${bgColor};
                padding: ${bgColor !== 'transparent' ? '20px' : '0'};
                border-radius: ${bgColor !== 'transparent' ? '8px' : '0'};
            ">${entry.content}</div>
            ${imagesHtml}
            <div class="diary-tags">
                ${entry.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
            </div>
            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(0,0,0,0.1); text-align: right;">
                <button onclick="deleteDiary(${entry.id})" style="
                    background: transparent;
                    color: #999;
                    border: none;
                    padding: 5px 10px;
                    cursor: pointer;
                    font-size: 0.8em;
                    transition: all 0.3s;
                    opacity: 0.5;
                " onmouseover="this.style.color='#e74c3c'; this.style.opacity='1'" onmouseout="this.style.color='#999'; this.style.opacity='0.5'">
                    删除
                </button>
            </div>
        </article>
        <div id="commentsSection"></div>
    `;
    
    // 渲染评论
    renderComments(entry.id);

    // 设置导航按钮
    const entries = Storage.getAll();
    const currentIndex = entries.findIndex(e => e.id === id);
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    if (currentIndex > 0) {
        prevBtn.href = `post.html?id=${entries[currentIndex - 1].id}`;
        prevBtn.classList.remove('disabled');
    } else {
        prevBtn.classList.add('disabled');
        prevBtn.href = '#';
    }

    if (currentIndex < entries.length - 1) {
        nextBtn.href = `post.html?id=${entries[currentIndex + 1].id}`;
        nextBtn.classList.remove('disabled');
    } else {
        nextBtn.classList.add('disabled');
        nextBtn.href = '#';
    }

    navContainer.style.display = 'flex';
}

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', renderDiaryDetail);
