// ==================== 获取 URL 参数 ====================
function getUrlParam(name) {
    const params = new URLSearchParams(window.location.search);
    return params.get(name);
}

// ==================== 打开图片模态框 ====================
function openImageModal(src) {
    document.getElementById('modalImage').src = src;
    document.getElementById('imageModal').classList.add('active');
}

// ==================== 关闭图片模态框 ====================
function closeImageModal() {
    document.getElementById('imageModal').classList.remove('active');
}

// ==================== 渲染日记详情 ====================
function renderDiaryDetail() {
    const id = parseInt(getUrlParam('id'));
    const contentContainer = document.getElementById('diaryContent');
    const navContainer = document.getElementById('diaryNav');
    
    if (!id) {
        contentContainer.innerHTML = `
            <div class="not-found">
                <h2>日记不存在</h2>
                <p>请检查链接是否正确</p>
                <a href="index.html" class="nav-btn" style="display: inline-block; margin-top: 20px;">返回首页</a>
            </div>
        `;
        return;
    }

    const entry = Storage.getById(id);
    
    if (!entry) {
        contentContainer.innerHTML = `
            <div class="not-found">
                <h2>日记不存在</h2>
                <p>该日记可能已被删除或链接错误</p>
                <a href="index.html" class="nav-btn" style="display: inline-block; margin-top: 20px;">返回首页</a>
            </div>
        `;
        return;
    }

    const start = new Date(CONFIG.START_DATE);
    const entryDate = new Date(entry.date);
    const dayCount = Math.floor((entryDate - start) / (1000 * 60 * 60 * 24)) + 1;
    const dateStr = `${entryDate.getFullYear()}年${entryDate.getMonth() + 1}月${entryDate.getDate()}日`;

    // 渲染图片
    let imagesHtml = '';
    if (entry.images && entry.images.length > 0) {
        if (entry.images.length === 1) {
            imagesHtml = `
                <div class="diary-image-single">
                    <img src="${entry.images[0]}" alt="日记图片" onclick="openImageModal('${entry.images[0]}')">
                </div>
            `;
        } else {
            imagesHtml = `
                <div class="diary-gallery">
                    <div class="gallery-grid">
                        ${entry.images.map(img => `
                            <div class="gallery-item" onclick="openImageModal('${img}')">
                                <img src="${img}" alt="日记图片">
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
    }

    // 应用自定义样式
    const fontFamily = entry.fontFamily || 'inherit';
    const fontSize = entry.fontSize || '1em';
    const fontColor = entry.fontColor || '#444';
    const bgColor = entry.bgColor || 'transparent';

    contentContainer.innerHTML = `
        <article class="diary-detail">
            <header class="diary-header">
                <div class="diary-meta">
                    <span class="diary-date">📅 ${dateStr}</span>
                    <span class="diary-day-count">第 ${dayCount} 天</span>
                </div>
                <h1 class="diary-title">${entry.title}</h1>
            </header>
            <div class="diary-content" style="
                font-family: ${fontFamily};
                font-size: ${fontSize};
                color: ${fontColor};
                background: ${bgColor};
                padding: ${bgColor !== 'transparent' ? '20px' : '0'};
                border-radius: ${bgColor !== 'transparent' ? '8px' : '0'};
            ">${entry.content}</div>
            ${imagesHtml}
            <div class="diary-tags">
                ${entry.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
            </div>
        </article>
    `;

    // 设置导航按钮
    const entries = Storage.getAll();
    const currentIndex = entries.findIndex(e => e.id === id);
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    if (currentIndex > 0) {
        prevBtn.href = `post.html?id=${entries[currentIndex - 1].id}`;
        prevBtn.classList.remove('disabled');
    } else {
        prevBtn.classList.add('disabled');
        prevBtn.href = '#';
    }

    if (currentIndex < entries.length - 1) {
        nextBtn.href = `post.html?id=${entries[currentIndex + 1].id}`;
        nextBtn.classList.remove('disabled');
    } else {
        nextBtn.classList.add('disabled');
        nextBtn.href = '#';
    }

    navContainer.style.display = 'flex';
}

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', renderDiaryDetail);
