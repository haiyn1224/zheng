// ==================== 倒计时功能 ====================
function updateCountdown() {
    const now = new Date().getTime();
    const target = new Date(CONFIG.TARGET_DATE).getTime();
    const start = new Date(CONFIG.START_DATE).getTime();
    
    const distance = target - now;
    const total = target - start;
    const elapsed = now - start;
    
    if (distance > 0) {
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        document.getElementById('days').textContent = days;
        document.getElementById('hours').textContent = hours;
        document.getElementById('minutes').textContent = minutes;
        document.getElementById('seconds').textContent = seconds;
        
        const progress = Math.min(100, Math.max(0, (elapsed / total) * 100));
        document.getElementById('progressFill').style.width = progress + '%';
        document.getElementById('progressPercent').textContent = progress.toFixed(1) + '%';
    } else {
        document.getElementById('days').textContent = '0';
        document.getElementById('hours').textContent = '0';
        document.getElementById('minutes').textContent = '0';
        document.getElementById('seconds').textContent = '0';
        document.getElementById('progressFill').style.width = '100%';
        document.getElementById('progressPercent').textContent = '100%';
        document.querySelector('.countdown-label').textContent = '约定之日已至';
    }
}

// ==================== 显示目标日期 ====================
function showTargetDate() {
    const targetDateObj = new Date(CONFIG.TARGET_DATE);
    document.getElementById('targetDate').textContent = 
        `${targetDateObj.getFullYear()}年${targetDateObj.getMonth() + 1}月${targetDateObj.getDate()}日`;
}

// ==================== 渲染日记列表 ====================
function renderDiaryList() {
    const listContainer = document.getElementById('diaryList');
    const entries = Storage.getAll();
    const start = new Date(CONFIG.START_DATE);
    
    if (entries.length === 0) {
        listContainer.innerHTML = '<div style="text-align:center;color:white;opacity:0.7;padding:40px;">还没有日记，点击"记录此刻"开始吧</div>';
        return;
    }
    
    listContainer.innerHTML = entries.map(entry => {
        const entryDate = new Date(entry.date);
        const dayCount = Math.floor((entryDate - start) / (1000 * 60 * 60 * 24)) + 1;
        const dateStr = `${entryDate.getFullYear()}年${entryDate.getMonth() + 1}月${entryDate.getDate()}日`;
        
        const imagesHtml = entry.images && entry.images.length > 0 
            ? `<div class="diary-images">
                ${entry.images.slice(0, 4).map(img => `<img src="${img}" alt="日记图片">`).join('')}
                ${entry.images.length > 4 ? `<div style="display:flex;align-items:center;justify-content:center;background:#f0f0f0;border-radius:8px;color:#999;font-size:0.9em;">+${entry.images.length - 4}</div>` : ''}
               </div>`
            : '';
        
        return `
            <a href="post.html?id=${entry.id}" class="diary-card">
                <div class="diary-header">
                    <span class="diary-date">📅 ${dateStr}</span>
                    <span class="diary-day-count">第 ${dayCount} 天</span>
                </div>
                <h3 class="diary-title">${entry.title}</h3>
                <p class="diary-excerpt">${entry.content}</p>
                ${imagesHtml}
                <div class="diary-footer">
                    <div class="diary-tags">
                        ${entry.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                    </div>
                    <span class="read-more">查看详情 →</span>
                </div>
            </a>
        `;
    }).join('');
}

// ==================== 初始化 ====================
function init() {
    showTargetDate();
    updateCountdown();
    setInterval(updateCountdown, 1000);
    renderDiaryList();
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', init);
