// ==================== 倒计时功能 ====================
function updateCountdown() {
    const now = new Date().getTime();
    const target = new Date(CONFIG.TARGET_DATE).getTime();
    const start = new Date(CONFIG.START_DATE).getTime();
    
    const distance = target - now;
    const total = target - start;
    const elapsed = now - start;
    
    if (distance > 0) {
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        document.getElementById('days').textContent = days;
        document.getElementById('hours').textContent = hours;
        document.getElementById('minutes').textContent = minutes;
        document.getElementById('seconds').textContent = seconds;
        
        const progress = Math.min(100, Math.max(0, (elapsed / total) * 100));
        document.getElementById('progressFill').style.width = progress + '%';
        document.getElementById('progressPercent').textContent = progress.toFixed(1) + '%';
    } else {
        document.getElementById('days').textContent = '0';
        document.getElementById('hours').textContent = '0';
        document.getElementById('minutes').textContent = '0';
        document.getElementById('seconds').textContent = '0';
        document.getElementById('progressFill').style.width = '100%';
        document.getElementById('progressPercent').textContent = '100%';
        document.querySelector('.countdown-label').textContent = '约定之日已至';
    }
}

// ==================== 显示目标日期 ====================
function showTargetDate() {
    const targetDateObj = new Date(CONFIG.TARGET_DATE);
    document.getElementById('targetDate').textContent = 
        `${targetDateObj.getFullYear()}年${targetDateObj.getMonth() + 1}月${targetDateObj.getDate()}日`;
}

// ==================== 删除日记（首页）====================
function deleteEntryFromList(id, event) {
    event.preventDefault();
    event.stopPropagation();
    
    const modal = document.createElement('div');
    modal.innerHTML = `
        <div style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            backdrop-filter: blur(5px);
        ">
            <div style="
                background: white;
                padding: 40px;
                border-radius: 20px;
                text-align: center;
                max-width: 400px;
                width: 90%;
            ">
                <div style="font-size: 3em; margin-bottom: 20px;">🔒</div>
                <h2 style="margin-bottom: 10px;">需要验证</h2>
                <p style="color: #666; margin-bottom: 20px;">请输入密码以删除日记</p>
                <input type="password" id="listPasswordInput" placeholder="请输入密码" style="
                    width: 100%;
                    padding: 12px;
                    border: 2px solid #ddd;
                    border-radius: 10px;
                    margin-bottom: 15px;
                    text-align: center;
                " onkeypress="if(event.key==='Enter')verifyListPassword(${id})">
                <button onclick="verifyListPassword(${id})" style="
                    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
                    color: white;
                    border: none;
                    padding: 12px 30px;
                    border-radius: 25px;
                    cursor: pointer;
                    width: 100%;
                    margin-bottom: 10px;
                ">验证并删除</button>
                <button onclick="this.closest('.modal').remove()" style="
                    background: none;
                    border: none;
                    color: #999;
                    cursor: pointer;
                ">取消</button>
                <p id="listPasswordError" style="color: #e74c3c; margin-top: 10px; display: none;">密码错误</p>
            </div>
        </div>
    `;
    modal.className = 'modal';
    document.body.appendChild(modal);
    document.getElementById('listPasswordInput').focus();
}

function verifyListPassword(id) {
    const input = document.getElementById('listPasswordInput');
    const error = document.getElementById('listPasswordError');
    
    if (Auth.verify(input.value)) {
        if (Storage.deleteEntry(id)) {
            renderDiaryList();
            document.querySelector('.modal').remove();
        }
    } else {
        error.style.display = 'block';
        input.value = '';
        input.focus();
    }
}

// ==================== 渲染日记列表 ====================
function renderDiaryList() {
    const listContainer = document.getElementById('diaryList');
    const entries = Storage.getAll();
    const start = new Date(CONFIG.START_DATE);
    
    if (entries.length === 0) {
        listContainer.innerHTML = '<div style="text-align:center;color:white;opacity:0.7;padding:40px;">还没有日记，点击"记录此刻"开始吧</div>';
        return;
    }
    
    listContainer.innerHTML = entries.map(entry => {
        const entryDate = new Date(entry.date);
        const dayCount = Math.floor((entryDate - start) / (1000 * 60 * 60 * 24)) + 1;
        const dateStr = `${entryDate.getFullYear()}年${entryDate.getMonth() + 1}月${entryDate.getDate()}日`;
        
        const imagesHtml = entry.images && entry.images.length > 0 
            ? `<div class="diary-images">
                ${entry.images.slice(0, 4).map(img => `<img src="${img}" alt="日记图片">`).join('')}
                ${entry.images.length > 4 ? `<div style="display:flex;align-items:center;justify-content:center;background:#f0f0f0;border-radius:8px;color:#999;font-size:0.9em;">+${entry.images.length - 4}</div>` : ''}
               </div>`
            : '';
        
        return `
            <div class="diary-card-wrapper" style="position: relative;">
                <a href="post.html?id=${entry.id}" class="diary-card">
                    <div class="diary-header">
                        <span class="diary-date">📅 ${dateStr}</span>
                        <span class="diary-day-count">第 ${dayCount} 天</span>
                    </div>
                    <h3 class="diary-title">${entry.title}</h3>
                    <p class="diary-excerpt">${entry.content}</p>
                    ${imagesHtml}
                    <div class="diary-footer">
                        <div class="diary-tags">
                            ${entry.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                        </div>
                        <span class="read-more">查看详情 →</span>
                    </div>
                </a>
                <button onclick="deleteEntryFromList(${entry.id}, event)" style="
                    position: absolute;
                    top: 15px;
                    right: 15px;
                    background: rgba(0,0,0,0.1);
                    color: rgba(255,255,255,0.4);
                    border: none;
                    width: 24px;
                    height: 24px;
                    border-radius: 50%;
                    cursor: pointer;
                    font-size: 1em;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 10;
                    transition: all 0.3s;
                    opacity: 0;
                " onmouseover="this.style.background='rgba(231,76,60,0.8)'; this.style.color='white'; this.style.opacity='1'" onmouseout="this.style.background='rgba(0,0,0,0.1)'; this.style.color='rgba(255,255,255,0.4)'; this.style.opacity='0'" class="delete-btn">
                    ×
                </button>
            </div>
        `;
    }).join('');
}

// ==================== 初始化 ====================
function init() {
    showTargetDate();
    updateCountdown();
    setInterval(updateCountdown, 1000);
    renderDiaryList();
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', init);
